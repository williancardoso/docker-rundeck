#!/usr/bin/env bash

# variables set by plugin properties:
: ${RD_CONFIG_HOSTT:?"account plugin property not specified"}
: ${RD_CONFIG_USER:?"region plugin property not specified"}
: ${RD_CONFIG_PASSWORD:?"url plugin property not specified"}

#
# Generate node data here.
#

exit $?
